#include "PointEffector.h"

void PointEffector::Apply(std::vector<Body>& bodies)
{
	for (auto& body : bodies)
	{
		Vector2 direction = {body.position.x - position.x,body.position.y - position.y};
		
		if (Vector2Length(direction) <= size)
		{
			Vector2 force = Vector2Normalize(direction) * forceMagnitude;
			body.addForce(force);
		}
	}
}

void PointEffector::Draw()
{
	DrawCircleLinesV(position, size, RED);
}
